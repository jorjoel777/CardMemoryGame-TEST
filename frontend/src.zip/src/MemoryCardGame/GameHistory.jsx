import React, { useEffect, useState } from 'react';
import axios from 'axios';

const GameHistory = () => {
  const [history, setHistory] = useState([]);
  const userID = localStorage.getItem('userID');

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/memory/${userID}`);
        setHistory(response.data.history);
      } catch (error) {
        console.error("Error fetching history:", error);
      }
    };

    if (userID) fetchHistory();
  }, [userID]);

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Game History</h2>
      {history.length === 0 ? (
        <p>No game history available.</p>
      ) : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>Date</th>
              <th>Difficulty</th>
              <th>Time Taken</th>
              <th>Completed</th>
              <th>Failed</th>
            </tr>
          </thead>
          <tbody>
            {history.map((item, index) => (
              <tr key={index}>
                <td>{new Date(item.gameDate).toLocaleString()}</td>
                <td>{item.difficulty}</td>
                <td>{item.timeTaken}s</td>
                <td>{item.completed ? '✔️' : '❌'}</td>
                <td>{item.failed ? '❌' : '✔️'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default GameHistory;
